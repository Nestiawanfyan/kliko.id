<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisHunian extends Model
{
    protected $table = 'jenis_hunian';
}
