<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kost_parkir extends Model
{
    protected $table = 'kost_parkir';
}
