<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kost_fu extends Model
{
    protected $table = 'kost_fu';
}
