<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FasilitasKategori extends Model
{
    protected $table = 'fasilitas_kategori';   
}
