<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class kost_fl extends Model
{
    protected $table = 'kost_fl';
}
