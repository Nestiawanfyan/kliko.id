<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JenisListrik extends Model
{
    protected $table = 'jenis_listrik';
}
