<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FasilitasKost extends Model
{
    protected $table = 'fasilitas_kost';   
}
