<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FR extends Model
{
    protected $table = 'fasilitas_ruangan';

}
