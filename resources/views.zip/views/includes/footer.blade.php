<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.3.3
  </div>
  <strong>Copyright &copy;
    @if(date('Y')!=2016)
    2016 -
    @endif
    {{ date('Y') }} <a href="#">Kliko.id</a>.</strong> All rights
  reserved.
</footer>
