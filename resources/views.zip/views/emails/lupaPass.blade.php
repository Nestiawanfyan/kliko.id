<div style=\"background: #fafafa; padding: 0px 25px;\">
	<div style=\"background: #fff; color: #444;\">
		<div style=\"padding:25px 20px 10px; background: #025aa5; border-bottom: 1px solid #fafafa; color: #FFF;\">
			<h3><a href=\"".kost_domain()."\" style=\"font-size: 25px; text-transform: uppercase; text-decoration:none; color: #FFF;\">Kliko</a></h3>
		</div>
		<div style=\"padding: 20px; border-bottom: 1px solid #fafafa;\">
			<h4 style=\"text-decoration: none; color:#444; font-size:18px;\">Selamat Datang di Kliko</h4>
			<p><strong>Kliko</strong> merupakan situs yang menyediakan layanan informasi seputar kos-kosan di wilayah Bandar Lampung dan sekitarnya. Anda bisa memasang iklan gratis di Kliko.</p>
		</div>
		<div style=\"padding: 20px; border-bottom: 1px solid #fafafa;\">
			<p>Anda telah meminta untuk merubah password Anda. Di bawah ini adalah informasi terbaru dari akun Anda.</p>
			<p>
				Nama			: {{ $nama }} <br>
				Email			: {{ $email }} <br>
				Username	: {{ $username }} <br>
				Password	: {{ $password }} <br>
			</p>
		</div>
		<div style=\"padding: 20px; font-size: 12px; border-bottom: 1px solid #fafafa;\">
			<p style=\"font-size: 10px;\">Copyright &copy; <?php echo date('Y') ?> kliko.id All Rights Reserved</p>
		</div>
	</div>
</div>
